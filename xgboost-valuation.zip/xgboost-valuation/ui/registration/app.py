"""
User Registration System Module

This module implements the multi-step registration process for the XGBoost home valuation system.
It includes basic information collection, identity verification, and agent notification system.
"""

import os
import json
import dash
from dash import dcc, html, callback, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import uuid
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import base64
import io
from fpdf import FPDF

# Create the Dash app
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
    suppress_callback_exceptions=True
)

# Define the layout for the registration system
def create_registration_layout():
    """
    Create the layout for the registration system.
    
    Returns:
        dash.html.Div: The layout for the registration system.
    """
    return html.Div([
        # Header
        html.Div([
            html.H1("User Registration - XGBoost Home Valuation", className="header-title"),
            html.P("Clark County, Nevada", className="header-subtitle"),
        ], className="header"),
        
        # Main content
        html.Div([
            # Progress bar
            html.Div([
                html.Div([
                    html.Div(className="progress-bar", id="progress-bar"),
                ], className="progress"),
                html.Div([
                    html.Div("Step 1: Basic Information", className="step-label", id="step1-label"),
                    html.Div("Step 2: Identity Verification", className="step-label", id="step2-label"),
                    html.Div("Step 3: Agent Notification", className="step-label", id="step3-label"),
                ], className="progress-labels"),
            ], className="progress-container"),
            
            # Step 1: Basic Information
            html.Div([
                html.H2("Step 1: Basic Information"),
                html.P("Please provide your personal information to get started."),
                
                html.Div([
                    html.Div([
                        html.Label("Full Legal Name *"),
                        dcc.Input(id="full-name-input", type="text", placeholder="Enter your full legal name", className="form-control"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Email Address *"),
                        dcc.Input(id="email-input", type="email", placeholder="Enter your email address", className="form-control"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Phone Number *"),
                        dcc.Input(id="phone-input", type="tel", placeholder="Enter your phone number", className="form-control"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Marital Status *"),
                        dcc.Dropdown(
                            id="marital-status-dropdown",
                            options=[
                                {"label": "Single", "value": "single"},
                                {"label": "Married", "value": "married"},
                                {"label": "Divorced", "value": "divorced"}
                            ],
                            placeholder="Select your marital status",
                            className="form-control"
                        ),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Current Address *"),
                        dcc.Input(id="address-line1-input", type="text", placeholder="Address Line 1", className="form-control"),
                        dcc.Input(id="address-line2-input", type="text", placeholder="Address Line 2 (optional)", className="form-control"),
                        html.Div([
                            dcc.Input(id="city-input", type="text", placeholder="City", className="form-control"),
                            dcc.Input(id="state-input", type="text", placeholder="State", className="form-control"),
                            dcc.Input(id="zip-input", type="text", placeholder="ZIP Code", className="form-control"),
                        ], className="address-row"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("User Type *"),
                        dcc.RadioItems(
                            id="user-type-radio",
                            options=[
                                {"label": "Buyer", "value": "buyer"},
                                {"label": "Seller", "value": "seller"}
                            ],
                            value="buyer",
                            className="form-control radio-group"
                        ),
                    ], className="form-group"),
                    
                    html.Div(id="step1-error-message", className="error-message"),
                    
                    html.Button("Continue to Step 2", id="step1-continue-button", className="btn btn-primary btn-block"),
                ], className="form-container"),
            ], id="step1-container", className="step-container"),
            
            # Step 2: Identity Verification
            html.Div([
                html.H2("Step 2: Identity Verification"),
                html.P("Please verify your identity and accept the required disclosures."),
                
                html.Div([
                    html.Div([
                        html.Label("Property Ownership Declaration"),
                        dcc.RadioItems(
                            id="ownership-radio",
                            options=[
                                {"label": "I am the legal owner of the property I am selling", "value": "owner"},
                                {"label": "I am authorized to act on behalf of the property owner", "value": "authorized"},
                                {"label": "I am a potential buyer", "value": "buyer"}
                            ],
                            className="form-control radio-group"
                        ),
                    ], className="form-group", id="ownership-container"),
                    
                    html.Div([
                        html.Label("Legal Acknowledgment"),
                        html.Div([
                            dcc.Checklist(
                                id="legal-checklist",
                                options=[
                                    {"label": "I acknowledge that all information provided is accurate and complete to the best of my knowledge.", "value": "accurate"},
                                    {"label": "I understand that providing false information may be subject to penalty of perjury under Nevada law.", "value": "perjury"}
                                ],
                                className="form-control checklist"
                            ),
                        ], className="checklist-container"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("State-Specific Disclosures"),
                        html.Div([
                            html.Div([
                                html.H4("Required Nevada Real Estate Disclosures"),
                                html.P("Please review and acknowledge the following required disclosures:"),
                                html.Div([
                                    html.Div([
                                        html.H5("Residential Disclosure Guide"),
                                        html.Button("View Document", id="view-disclosure1-button", className="btn btn-secondary btn-sm"),
                                        dcc.Checklist(
                                            id="disclosure1-checklist",
                                            options=[
                                                {"label": "I have reviewed and acknowledge this disclosure", "value": "acknowledged"}
                                            ],
                                            className="form-control checklist"
                                        ),
                                    ], className="disclosure-item"),
                                    
                                    html.Div([
                                        html.H5("Duties Owed by a Nevada Real Estate Licensee"),
                                        html.Button("View Document", id="view-disclosure2-button", className="btn btn-secondary btn-sm"),
                                        dcc.Checklist(
                                            id="disclosure2-checklist",
                                            options=[
                                                {"label": "I have reviewed and acknowledge this disclosure", "value": "acknowledged"}
                                            ],
                                            className="form-control checklist"
                                        ),
                                    ], className="disclosure-item"),
                                    
                                    html.Div([
                                        html.H5("Lead-Based Paint Disclosure"),
                                        html.Button("View Document", id="view-disclosure3-button", className="btn btn-secondary btn-sm"),
                                        dcc.Checklist(
                                            id="disclosure3-checklist",
                                            options=[
                                                {"label": "I have reviewed and acknowledge this disclosure", "value": "acknowledged"}
                                            ],
                                            className="form-control checklist"
                                        ),
                                    ], className="disclosure-item", id="lead-paint-container"),
                                    
                                    html.Div([
                                        html.H5(id="agreement-title"),
                                        html.Button("View Document", id="view-agreement-button", className="btn btn-secondary btn-sm"),
                                        dcc.Checklist(
                                            id="agreement-checklist",
                                            options=[
                                                {"label": "I have reviewed and acknowledge this agreement", "value": "acknowledged"}
                                            ],
                                            className="form-control checklist"
                                        ),
                                    ], className="disclosure-item"),
                                ], className="disclosures-list"),
                            ], className="disclosures-container"),
                        ], className="disclosures-wrapper"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Electronic Signature"),
                        html.P("By typing your name below, you are signing this document electronically. You agree your electronic signature is the legal equivalent of your manual signature."),
                        dcc.Input(id="signature-input", type="text", placeholder="Type your full legal name", className="form-control"),
                        html.Div(id="signature-preview", className="signature-preview"),
                    ], className="form-group"),
                    
                    html.Div(id="step2-error-message", className="error-message"),
                    
                    html.Div([
                        html.Button("Back to Step 1", id="step2-back-button", className="btn btn-secondary"),
                        html.Button("Continue to Step 3", id="step2-continue-button", className="btn btn-primary"),
                    ], className="button-group"),
                ], className="form-container"),
            ], id="step2-container", className="step-container", style={"display": "none"}),
            
            # Step 3: Agent Notification
            html.Div([
                html.H2("Step 3: Agent Notification"),
                html.P("Please provide agent information for notification of completed forms."),
                
                html.Div([
                    html.Div([
                        html.Label("Agent Email *"),
                        dcc.Input(id="agent-email-input", type="email", placeholder="Enter agent's email address", className="form-control"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Additional Recipients (Optional)"),
                        dcc.Input(id="additional-email1-input", type="email", placeholder="Additional email address", className="form-control"),
                        dcc.Input(id="additional-email2-input", type="email", placeholder="Additional email address", className="form-control"),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Notification Preferences"),
                        dcc.Checklist(
                            id="notification-checklist",
                            options=[
                                {"label": "Send me a copy of all documents", "value": "copy"},
                                {"label": "Send notification when agent views documents", "value": "viewed"},
                                {"label": "Allow agent to contact me directly", "value": "contact"}
                            ],
                            value=["copy", "contact"],
                            className="form-control checklist"
                        ),
                    ], className="form-group"),
                    
                    html.Div([
                        html.Label("Additional Notes (Optional)"),
                        dcc.Textarea(id="notes-input", placeholder="Enter any additional notes for the agent", className="form-control", style={"height": "100px"}),
                    ], className="form-group"),
                    
                    html.Div(id="step3-error-message", className="error-message"),
                    
                    html.Div([
                        html.Button("Back to Step 2", id="step3-back-button", className="btn btn-secondary"),
                        html.Button("Complete Registration", id="complete-button", className="btn btn-primary"),
                    ], className="button-group"),
                ], className="form-container"),
            ], id="step3-container", className="step-container", style={"display": "none"}),
            
            # Completion Screen
            html.Div([
                html.H2("Registration Complete!"),
                html.Div([
                    html.Div(className="success-icon"),
                    html.H3("Thank You for Registering"),
                    html.P("Your registration has been successfully completed and all documents have been generated."),
                    html.P("A confirmation email has been sent to your email address with copies of all signed documents."),
                    html.P("Your agent has been notified and will contact you shortly."),
                ], className="completion-message"),
                
                html.Div([
                    html.H4("Registration Summary"),
                    html.Div(id="registration-summary", className="registration-summary"),
                ], className="summary-container"),
                
                html.Div([
                    html.H4("Generated Documents"),
                    html.Div(id="documents-list", className="documents-list"),
                ], className="documents-container"),
                
                html.Div([
                    html.Button("Download All Documents", id="download-all-button", className="btn btn-primary"),
                    html.A(id="download-link", style={"display": "none"}),
                    html.Button("Return to Home", id="return-home-button", className="btn btn-secondary"),
                ], className="button-group"),
            ], id="completion-container", className="step-container", style={"display": "none"}),
            
            # Document Viewer Modal
            html.Div([
                html.Div([
                    html.Div([
                        html.Div([
                            html.H3(id="modal-title"),
                            html.Button("×", id="close-modal-button", className="close-button"),
                        ], className="modal-header"),
                        html.Div(id="modal-content", className="modal-content"),
                        html.Div([
                            html.Button("Close", id="modal-close-button", className="btn btn-secondary"),
                        ], className="modal-footer"),
                    ], className="modal-container"),
                ], className="modal-backdrop"),
            ], id="document-modal", className="modal", style={"display": "none"}),
        ], className="main-content"),
        
        # Footer
        html.Div([
            html.P("© 2025 XGBoost Home Valuation System | Clark County, Nevada"),
            html.P([
                html.A("Terms of Service", href="#"),
                " | ",
                html.A("Privacy Policy", href="#"),
                " | ",
                html.A("Contact Us", href="#"),
            ]),
        ], className="footer"),
        
        # Store components for intermediate data
        dcc.Store(id="user-data-store"),
        dcc.Store(id="verification-data-store"),
        dcc.Store(id="notification-data-store"),
        dcc.Store(id="documents-data-store"),
    ], className="app-container")

# Set the app layout
app.layout = create_registration_layout()

# Callback to update progress bar
@app.callback(
    [
        Output("progress-bar", "style"),
        Output("step1-label", "className"),
        Output("step2-label", "className"),
        Output("step3-label", "className"),
    ],
    [
        Input("step1-container", "style"),
        Input("step2-container", "style"),
        Input("step3-container", "style"),
        Input("completion-container", "style"),
    ]
)
def update_progress_bar(step1_style, step2_style, step3_style, completion_style):
    """
    Update the progress bar based on the current step.
    
    Args:
        step1_style: Style of step 1 container.
        step2_style: Style of step 2 container.
        step3_style: Style of step 3 container.
        completion_style: Style of completion container.
        
    Returns:
        tuple: Updated progress bar style and step label classes.
    """
    # Determine current step
    if step1_style is None or "display" not in step1_style or step1_style["display"] != "none":
        progress_width = "33%"
        step1_class = "step-label active"
        step2_class = "step-label"
        step3_class = "step-label"
    elif step2_style is None or "display" not in step2_style or step2_style["display"] != "none":
        progress_width = "66%"
        step1_class = "step-label completed"
        step2_class = "step-label active"
        step3_class = "step-label"
    elif step3_style is None or "display" not in step3_style or step3_style["display"] != "none":
        progress_width = "100%"
        step1_class = "step-label completed"
        step2_class = "step-label completed"
        step3_class = "step-label active"
    else:
        progress_width = "100%"
        step1_class = "step-label completed"
        step2_class = "step-label completed"
        step3_class = "step-label completed"
    
    return {"width": progress_width}, step1_class, step2_class, step3_class

# Callback to validate step 1 and proceed to step 2
@app.callback(
    [
        Output("step1-container", "style"),
        Output("step2-container", "style"),
        Output("step1-error-message", "children"),
        Output("user-data-store", "data"),
        Output("ownership-container", "style"),
        Output("lead-paint-container", "style"),
        Output("agreement-title", "children"),
    ],
    [Input("step1-continue-button", "n_clicks")],
    [
        State("full-name-input", "value"),
        State("email-input", "value"),
        State("phone-input", "value"),
        State("marital-status-dropdown", "value"),
        State("address-line1-input", "value"),
        State("address-line2-input", "value"),
        State("city-input", "value"),
        State("state-input", "value"),
        State("zip-input", "value"),
        State("user-type-radio", "value"),
        State("user-data-store", "data"),
    ],
    prevent_initial_call=True
)
def validate_step1(n_clicks, full_name, email, phone, marital_status, address_line1, 
                  address_line2, city, state, zip_code, user_type, existing_data):
    """
    Validate step 1 inputs and proceed to step 2.
    
    Args:
        n_clicks: Number of clicks on the continue button.
        full_name: Full legal name.
        email: Email address.
        phone: Phone number.
        marital_status: Marital status.
        address_line1: Address line 1.
        address_line2: Address line 2.
        city: City.
        state: State.
        zip_code: ZIP code.
        user_type: User type (buyer or seller).
        existing_data: Existing user data.
        
    Returns:
        tuple: Updated container styles, error message, user data, and step 2 configurations.
    """
    if not n_clicks:
        return dash.no_update
    
    # Validate required fields
    error_message = None
    if not full_name:
        error_message = "Please enter your full legal name."
    elif not email or "@" not in email:
        error_message = "Please enter a valid email address."
    elif not phone:
        error_message = "Please enter your phone number."
    elif not marital_status:
        error_message = "Please select your marital status."
    elif not address_line1:
        error_message = "Please enter your address."
    elif not city:
        error_message = "Please enter your city."
    elif not state:
        error_message = "Please enter your state."
    elif not zip_code:
        error_message = "Please enter your ZIP code."
    
    if error_message:
        return dash.no_update, dash.no_update, error_message, dash.no_update, dash.no_update, dash.no_update, dash.no_update
    
    # Create user data
    user_data = {
        "full_name": full_name,
        "email": email,
        "phone": phone,
        "marital_status": marital_status,
        "address": {
            "line1": address_line1,
            "line2": address_line2 or "",
            "city": city,
            "state": state,
            "zip": zip_code
        },
        "user_type": user_type,
        "registration_id": str(uuid.uuid4()),
        "registration_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    # Determine ownership container visibility
    ownership_container_style = {"display": "block"} if user_type == "seller" else {"display": "none"}
    
    # Determine lead paint container visibility (only for properties built before 1978)
    lead_paint_container_style = {"display": "block"}
    
    # Determine agreement title based on user type
    agreement_title = "Exclusive Authorization and Right to Sell" if user_type == "seller" else "Buyer Brokerage Representation Agreement"
    
    return {"display": "none"}, {"display": "block"}, None, user_data, ownership_container_style, lead_paint_container_style, agreement_title

# Callback to go back from step 2 to step 1
@app.callback(
    [
        Output("step1-container", "style", allow_duplicate=True),
        Output("step2-container", "style", allow_duplicate=True),
    ],
    [Input("step2-back-button", "n_clicks")],
    prevent_initial_call=True
)
def back_to_step1(n_clicks):
    """
    Go back from step 2 to step 1.
    
    Args:
        n_clicks: Number of clicks on the back button.
        
    Returns:
        tuple: Updated container styles.
    """
    if not n_clicks:
        return dash.no_update
    
    return {"display": "block"}, {"display": "none"}

# Callback to update signature preview
@app.callback(
    Output("signature-preview", "children"),
    [Input("signature-input", "value")],
    [State("user-data-store", "data")]
)
def update_signature_preview(signature, user_data):
    """
    Update the signature preview.
    
    Args:
        signature: Signature input.
        user_data: User data.
        
    Returns:
        html.Div: Signature preview.
    """
    if not signature:
        return ""
    
    # Check if signature matches full name
    if user_data and "full_name" in user_data:
        full_name = user_data["full_name"]
        if signature.lower() != full_name.lower():
            return html.Div([
                html.Div(signature, className="signature-text"),
                html.Div("Signature does not match your full legal name.", className="signature-warning"),
            ])
    
    return html.Div(signature, className="signature-text")

# Callback to validate step 2 and proceed to step 3
@app.callback(
    [
        Output("step2-container", "style", allow_duplicate=True),
        Output("step3-container", "style"),
        Output("step2-error-message", "children"),
        Output("verification-data-store", "data"),
    ],
    [Input("step2-continue-button", "n_clicks")],
    [
        State("ownership-radio", "value"),
        State("legal-checklist", "value"),
        State("disclosure1-checklist", "value"),
        State("disclosure2-checklist", "value"),
        State("disclosure3-checklist", "value"),
        State("agreement-checklist", "value"),
        State("signature-input", "value"),
        State("user-data-store", "data"),
    ],
    prevent_initial_call=True
)
def validate_step2(n_clicks, ownership, legal_checklist, disclosure1, disclosure2, disclosure3, 
                  agreement, signature, user_data):
    """
    Validate step 2 inputs and proceed to step 3.
    
    Args:
        n_clicks: Number of clicks on the continue button.
        ownership: Property ownership declaration.
        legal_checklist: Legal acknowledgment checklist.
        disclosure1: Residential Disclosure Guide acknowledgment.
        disclosure2: Duties Owed acknowledgment.
        disclosure3: Lead-Based Paint Disclosure acknowledgment.
        agreement: Agreement acknowledgment.
        signature: Electronic signature.
        user_data: User data.
        
    Returns:
        tuple: Updated container styles, error message, and verification data.
    """
    if not n_clicks:
        return dash.no_update
    
    # Validate required fields
    error_message = None
    
    if user_data["user_type"] == "seller" and not ownership:
        error_message = "Please select your property ownership status."
    elif not legal_checklist or len(legal_checklist) < 2:
        error_message = "Please acknowledge all legal statements."
    elif not disclosure1 or "acknowledged" not in disclosure1:
        error_message = "Please acknowledge the Residential Disclosure Guide."
    elif not disclosure2 or "acknowledged" not in disclosure2:
        error_message = "Please acknowledge the Duties Owed by a Nevada Real Estate Licensee."
    elif not disclosure3 or "acknowledged" not in disclosure3:
        error_message = "Please acknowledge the Lead-Based Paint Disclosure."
    elif not agreement or "acknowledged" not in agreement:
        error_message = "Please acknowledge the Agreement."
    elif not signature:
        error_message = "Please provide your electronic signature."
    elif user_data and "full_name" in user_data and signature.lower() != user_data["full_name"].lower():
        error_message = "Your signature must match your full legal name."
    
    if error_message:
        return dash.no_update, dash.no_update, error_message, dash.no_update
    
    # Create verification data
    verification_data = {
        "ownership": ownership if user_data["user_type"] == "seller" else "buyer",
        "legal_acknowledgments": legal_checklist,
        "disclosures_acknowledged": {
            "residential_disclosure_guide": True if disclosure1 and "acknowledged" in disclosure1 else False,
            "duties_owed": True if disclosure2 and "acknowledged" in disclosure2 else False,
            "lead_based_paint": True if disclosure3 and "acknowledged" in disclosure3 else False,
            "agreement": True if agreement and "acknowledged" in agreement else False
        },
        "signature": signature,
        "signature_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    return {"display": "none"}, {"display": "block"}, None, verification_data

# Callback to go back from step 3 to step 2
@app.callback(
    [
        Output("step2-container", "style", allow_duplicate=True),
        Output("step3-container", "style", allow_duplicate=True),
    ],
    [Input("step3-back-button", "n_clicks")],
    prevent_initial_call=True
)
def back_to_step2(n_clicks):
    """
    Go back from step 3 to step 2.
    
    Args:
        n_clicks: Number of clicks on the back button.
        
    Returns:
        tuple: Updated container styles.
    """
    if not n_clicks:
        return dash.no_update
    
    return {"display": "block"}, {"display": "none"}

# Callback to validate step 3 and complete registration
@app.callback(
    [
        Output("step3-container", "style", allow_duplicate=True),
        Output("completion-container", "style"),
        Output("step3-error-message", "children"),
        Output("notification-data-store", "data"),
        Output("documents-data-store", "data"),
        Output("registration-summary", "children"),
        Output("documents-list", "children"),
    ],
    [Input("complete-button", "n_clicks")],
    [
        State("agent-email-input", "value"),
        State("additional-email1-input", "value"),
        State("additional-email2-input", "value"),
        State("notification-checklist", "value"),
        State("notes-input", "value"),
        State("user-data-store", "data"),
        State("verification-data-store", "data"),
    ],
    prevent_initial_call=True
)
def complete_registration(n_clicks, agent_email, additional_email1, additional_email2, 
                         notification_prefs, notes, user_data, verification_data):
    """
    Validate step 3 inputs and complete registration.
    
    Args:
        n_clicks: Number of clicks on the complete button.
        agent_email: Agent email.
        additional_email1: Additional email 1.
        additional_email2: Additional email 2.
        notification_prefs: Notification preferences.
        notes: Additional notes.
        user_data: User data.
        verification_data: Verification data.
        
    Returns:
        tuple: Updated container styles, error message, notification data, documents data, registration summary, and documents list.
    """
    if not n_clicks:
        return dash.no_update
    
    # Validate required fields
    error_message = None
    
    if not agent_email or "@" not in agent_email:
        error_message = "Please enter a valid agent email address."
    
    if error_message:
        return dash.no_update, dash.no_update, error_message, dash.no_update, dash.no_update, dash.no_update, dash.no_update
    
    # Create notification data
    notification_data = {
        "agent_email": agent_email,
        "additional_recipients": [email for email in [additional_email1, additional_email2] if email and "@" in email],
        "notification_preferences": notification_prefs or [],
        "notes": notes or "",
        "notification_sent": True,
        "notification_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    # Generate documents
    documents_data = generate_documents(user_data, verification_data, notification_data)
    
    # Create registration summary
    registration_summary = html.Div([
        html.Div([
            html.Div([
                html.H5("Name"),
                html.P(user_data["full_name"]),
            ], className="summary-item"),
            html.Div([
                html.H5("Email"),
                html.P(user_data["email"]),
            ], className="summary-item"),
            html.Div([
                html.H5("Phone"),
                html.P(user_data["phone"]),
            ], className="summary-item"),
            html.Div([
                html.H5("User Type"),
                html.P("Seller" if user_data["user_type"] == "seller" else "Buyer"),
            ], className="summary-item"),
        ], className="summary-row"),
        html.Div([
            html.Div([
                html.H5("Registration ID"),
                html.P(user_data["registration_id"]),
            ], className="summary-item"),
            html.Div([
                html.H5("Registration Date"),
                html.P(user_data["registration_date"]),
            ], className="summary-item"),
            html.Div([
                html.H5("Agent Email"),
                html.P(notification_data["agent_email"]),
            ], className="summary-item"),
        ], className="summary-row"),
    ])
    
    # Create documents list
    documents_list = html.Div([
        html.Div([
            html.Div([
                html.H5(doc["title"]),
                html.P(f"Generated on {doc['generation_date']}"),
            ], className="document-info"),
            html.Div([
                html.Button("View", id=f"view-doc-{i}-button", className="btn btn-secondary btn-sm"),
                html.Button("Download", id=f"download-doc-{i}-button", className="btn btn-primary btn-sm"),
            ], className="document-actions"),
        ], className="document-item")
        for i, doc in enumerate(documents_data["documents"])
    ])
    
    return {"display": "none"}, {"display": "block"}, None, notification_data, documents_data, registration_summary, documents_list

# Helper function to generate documents
def generate_documents(user_data, verification_data, notification_data):
    """
    Generate documents based on user data, verification data, and notification data.
    
    Args:
        user_data: User data.
        verification_data: Verification data.
        notification_data: Notification data.
        
    Returns:
        dict: Documents data.
    """
    # Generate documents based on user type
    documents = []
    
    # Common documents
    documents.append({
        "title": "Registration Confirmation",
        "filename": f"registration_confirmation_{user_data['registration_id']}.pdf",
        "type": "confirmation",
        "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "content": generate_confirmation_pdf(user_data, verification_data, notification_data)
    })
    
    documents.append({
        "title": "Duties Owed by a Nevada Real Estate Licensee",
        "filename": f"duties_owed_{user_data['registration_id']}.pdf",
        "type": "disclosure",
        "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "content": "PDF content would be generated here"
    })
    
    documents.append({
        "title": "Lead-Based Paint Disclosure",
        "filename": f"lead_paint_disclosure_{user_data['registration_id']}.pdf",
        "type": "disclosure",
        "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "content": "PDF content would be generated here"
    })
    
    # User type specific documents
    if user_data["user_type"] == "seller":
        documents.append({
            "title": "Residential Disclosure Guide",
            "filename": f"residential_disclosure_{user_data['registration_id']}.pdf",
            "type": "disclosure",
            "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "content": "PDF content would be generated here"
        })
        
        documents.append({
            "title": "Exclusive Authorization and Right to Sell",
            "filename": f"listing_agreement_{user_data['registration_id']}.pdf",
            "type": "agreement",
            "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "content": "PDF content would be generated here"
        })
    else:  # buyer
        documents.append({
            "title": "Buyer Brokerage Representation Agreement",
            "filename": f"buyer_agreement_{user_data['registration_id']}.pdf",
            "type": "agreement",
            "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "content": "PDF content would be generated here"
        })
    
    # Create documents data
    documents_data = {
        "documents": documents,
        "zip_filename": f"all_documents_{user_data['registration_id']}.zip"
    }
    
    return documents_data

# Helper function to generate confirmation PDF
def generate_confirmation_pdf(user_data, verification_data, notification_data):
    """
    Generate a confirmation PDF.
    
    Args:
        user_data: User data.
        verification_data: Verification data.
        notification_data: Notification data.
        
    Returns:
        str: Base64 encoded PDF content.
    """
    # In a real implementation, this would generate a PDF using a library like FPDF
    # For this example, we'll just return a placeholder
    
    # Create a simple PDF
    pdf = FPDF()
    pdf.add_page()
    
    # Set font
    pdf.set_font("Arial", "B", 16)
    
    # Title
    pdf.cell(0, 10, "Registration Confirmation", 0, 1, "C")
    pdf.ln(10)
    
    # User information
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, "User Information", 0, 1, "L")
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 10, f"Name: {user_data['full_name']}", 0, 1, "L")
    pdf.cell(0, 10, f"Email: {user_data['email']}", 0, 1, "L")
    pdf.cell(0, 10, f"Phone: {user_data['phone']}", 0, 1, "L")
    pdf.cell(0, 10, f"User Type: {'Seller' if user_data['user_type'] == 'seller' else 'Buyer'}", 0, 1, "L")
    pdf.cell(0, 10, f"Registration ID: {user_data['registration_id']}", 0, 1, "L")
    pdf.cell(0, 10, f"Registration Date: {user_data['registration_date']}", 0, 1, "L")
    pdf.ln(10)
    
    # Verification information
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, "Verification Information", 0, 1, "L")
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 10, f"Signature: {verification_data['signature']}", 0, 1, "L")
    pdf.cell(0, 10, f"Signature Date: {verification_data['signature_date']}", 0, 1, "L")
    pdf.ln(10)
    
    # Notification information
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, "Notification Information", 0, 1, "L")
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 10, f"Agent Email: {notification_data['agent_email']}", 0, 1, "L")
    pdf.cell(0, 10, f"Notification Date: {notification_data['notification_date']}", 0, 1, "L")
    
    # Convert PDF to base64
    pdf_output = pdf.output(dest="S").encode("latin1")
    base64_pdf = base64.b64encode(pdf_output).decode("utf-8")
    
    return base64_pdf

# Callback to show document modal
@app.callback(
    [
        Output("document-modal", "style"),
        Output("modal-title", "children"),
        Output("modal-content", "children"),
    ],
    [
        Input("view-disclosure1-button", "n_clicks"),
        Input("view-disclosure2-button", "n_clicks"),
        Input("view-disclosure3-button", "n_clicks"),
        Input("view-agreement-button", "n_clicks"),
    ],
    [State("user-data-store", "data")],
    prevent_initial_call=True
)
def show_document_modal(disclosure1_clicks, disclosure2_clicks, disclosure3_clicks, agreement_clicks, user_data):
    """
    Show the document modal.
    
    Args:
        disclosure1_clicks: Number of clicks on the view disclosure 1 button.
        disclosure2_clicks: Number of clicks on the view disclosure 2 button.
        disclosure3_clicks: Number of clicks on the view disclosure 3 button.
        agreement_clicks: Number of clicks on the view agreement button.
        user_data: User data.
        
    Returns:
        tuple: Modal style, title, and content.
    """
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update
    
    button_id = ctx.triggered[0]["prop_id"].split(".")[0]
    
    if button_id == "view-disclosure1-button":
        title = "Residential Disclosure Guide"
        content = html.Div([
            html.P("This is a placeholder for the Residential Disclosure Guide document."),
            html.P("In a real implementation, this would display the actual document content or embed the PDF."),
        ])
    elif button_id == "view-disclosure2-button":
        title = "Duties Owed by a Nevada Real Estate Licensee"
        content = html.Div([
            html.P("This is a placeholder for the Duties Owed by a Nevada Real Estate Licensee document."),
            html.P("In a real implementation, this would display the actual document content or embed the PDF."),
        ])
    elif button_id == "view-disclosure3-button":
        title = "Lead-Based Paint Disclosure"
        content = html.Div([
            html.P("This is a placeholder for the Lead-Based Paint Disclosure document."),
            html.P("In a real implementation, this would display the actual document content or embed the PDF."),
        ])
    elif button_id == "view-agreement-button":
        if user_data and user_data["user_type"] == "seller":
            title = "Exclusive Authorization and Right to Sell"
        else:
            title = "Buyer Brokerage Representation Agreement"
        
        content = html.Div([
            html.P(f"This is a placeholder for the {title} document."),
            html.P("In a real implementation, this would display the actual document content or embed the PDF."),
        ])
    else:
        return dash.no_update
    
    return {"display": "block"}, title, content

# Callback to close document modal
@app.callback(
    Output("document-modal", "style", allow_duplicate=True),
    [
        Input("close-modal-button", "n_clicks"),
        Input("modal-close-button", "n_clicks"),
    ],
    prevent_initial_call=True
)
def close_document_modal(close_clicks, modal_close_clicks):
    """
    Close the document modal.
    
    Args:
        close_clicks: Number of clicks on the close button.
        modal_close_clicks: Number of clicks on the modal close button.
        
    Returns:
        dict: Modal style.
    """
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update
    
    return {"display": "none"}

# Callback to view generated documents
@app.callback(
    [
        Output("document-modal", "style", allow_duplicate=True),
        Output("modal-title", "children", allow_duplicate=True),
        Output("modal-content", "children", allow_duplicate=True),
    ],
    [
        Input("view-doc-0-button", "n_clicks"),
        Input("view-doc-1-button", "n_clicks"),
        Input("view-doc-2-button", "n_clicks"),
        Input("view-doc-3-button", "n_clicks"),
        Input("view-doc-4-button", "n_clicks"),
    ],
    [State("documents-data-store", "data")],
    prevent_initial_call=True
)
def view_generated_document(doc0_clicks, doc1_clicks, doc2_clicks, doc3_clicks, doc4_clicks, documents_data):
    """
    View a generated document.
    
    Args:
        doc0_clicks: Number of clicks on the view document 0 button.
        doc1_clicks: Number of clicks on the view document 1 button.
        doc2_clicks: Number of clicks on the view document 2 button.
        doc3_clicks: Number of clicks on the view document 3 button.
        doc4_clicks: Number of clicks on the view document 4 button.
        documents_data: Documents data.
        
    Returns:
        tuple: Modal style, title, and content.
    """
    ctx = dash.callback_context
    if not ctx.triggered or not documents_data:
        return dash.no_update
    
    button_id = ctx.triggered[0]["prop_id"].split(".")[0]
    
    if button_id.startswith("view-doc-"):
        doc_index = int(button_id.split("-")[2])
        
        if doc_index < len(documents_data["documents"]):
            document = documents_data["documents"][doc_index]
            
            title = document["title"]
            content = html.Div([
                html.P(f"This is a placeholder for the {title} document."),
                html.P("In a real implementation, this would display the actual document content or embed the PDF."),
                html.P(f"Generated on: {document['generation_date']}"),
            ])
            
            return {"display": "block"}, title, content
    
    return dash.no_update

# Callback to download generated documents
@app.callback(
    Output("download-link", "href"),
    [
        Input("download-doc-0-button", "n_clicks"),
        Input("download-doc-1-button", "n_clicks"),
        Input("download-doc-2-button", "n_clicks"),
        Input("download-doc-3-button", "n_clicks"),
        Input("download-doc-4-button", "n_clicks"),
        Input("download-all-button", "n_clicks"),
    ],
    [State("documents-data-store", "data")],
    prevent_initial_call=True
)
def download_document(doc0_clicks, doc1_clicks, doc2_clicks, doc3_clicks, doc4_clicks, download_all_clicks, documents_data):
    """
    Download a document.
    
    Args:
        doc0_clicks: Number of clicks on the download document 0 button.
        doc1_clicks: Number of clicks on the download document 1 button.
        doc2_clicks: Number of clicks on the download document 2 button.
        doc3_clicks: Number of clicks on the download document 3 button.
        doc4_clicks: Number of clicks on the download document 4 button.
        download_all_clicks: Number of clicks on the download all button.
        documents_data: Documents data.
        
    Returns:
        str: Download link href.
    """
    ctx = dash.callback_context
    if not ctx.triggered or not documents_data:
        return dash.no_update
    
    button_id = ctx.triggered[0]["prop_id"].split(".")[0]
    
    if button_id.startswith("download-doc-"):
        doc_index = int(button_id.split("-")[2])
        
        if doc_index < len(documents_data["documents"]):
            document = documents_data["documents"][doc_index]
            
            # In a real implementation, this would generate a download link for the actual document
            # For this example, we'll just return a placeholder
            return f"data:text/plain;charset=utf-8,{document['filename']}"
    
    elif button_id == "download-all-button":
        # In a real implementation, this would generate a download link for a ZIP file containing all documents
        # For this example, we'll just return a placeholder
        return f"data:text/plain;charset=utf-8,{documents_data['zip_filename']}"
    
    return dash.no_update

# Callback to return to home
@app.callback(
    Output("return-home-button", "href"),
    [Input("return-home-button", "n_clicks")],
    [State("user-data-store", "data")]
)
def return_to_home(n_clicks, user_data):
    """
    Return to home page.
    
    Args:
        n_clicks: Number of clicks on the return home button.
        user_data: User data.
        
    Returns:
        str: Home page URL.
    """
    if not n_clicks:
        return dash.no_update
    
    # Determine which portal to return to based on user type
    if user_data and user_data["user_type"] == "seller":
        return "/seller"
    else:
        return "/buyer"

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True, host='0.0.0.0', port=8052)
