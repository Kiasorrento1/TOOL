"""
User Interface Module for Buyer Portal

This module implements the user interface for the buyer portal of the XGBoost home valuation system.
It includes the total cost of ownership calculator, mortgage payment projections, property tax estimates,
insurance costs, maintenance projections, and equity building visualization.
"""

import os
import json
import dash
from dash import dcc, html, callback, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Create the Dash app
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
    suppress_callback_exceptions=True
)

# Define the layout for the buyer portal
def create_buyer_layout():
    """
    Create the layout for the buyer portal.
    
    Returns:
        dash.html.Div: The layout for the buyer portal.
    """
    return html.Div([
        # Header
        html.Div([
            html.H1("Buyer Portal - XGBoost Home Valuation", className="header-title"),
            html.P("Clark County, Nevada", className="header-subtitle"),
        ], className="header"),
        
        # Main content
        html.Div([
            # Sidebar
            html.Div([
                html.Div([
                    html.H4("Property Information"),
                    html.Div([
                        html.Label("Address"),
                        dcc.Input(id="address-input", type="text", placeholder="Enter property address", className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Property Type"),
                        dcc.Dropdown(
                            id="property-type-dropdown",
                            options=[
                                {"label": "Single Family", "value": "single_family"},
                                {"label": "Condo", "value": "condo"},
                                {"label": "Townhouse", "value": "townhouse"},
                                {"label": "Multi-Family", "value": "multi_family"}
                            ],
                            value="single_family",
                            className="form-control"
                        ),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Purchase Price"),
                        dcc.Input(id="purchase-price-input", type="number", min=100000, max=10000000, step=1000, value=400000, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Down Payment (%)"),
                        dcc.Slider(
                            id="down-payment-slider",
                            min=3,
                            max=50,
                            step=1,
                            value=20,
                            marks={i: f"{i}%" for i in range(0, 51, 5)},
                            className="form-control"
                        ),
                    ], className="form-group"),
                    html.Div(id="down-payment-amount", className="calculated-value"),
                    html.Div([
                        html.Label("Loan Term (years)"),
                        dcc.Dropdown(
                            id="loan-term-dropdown",
                            options=[
                                {"label": "15 Years", "value": 15},
                                {"label": "20 Years", "value": 20},
                                {"label": "30 Years", "value": 30}
                            ],
                            value=30,
                            className="form-control"
                        ),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Interest Rate (%)"),
                        dcc.Input(id="interest-rate-input", type="number", min=1, max=15, step=0.125, value=6.5, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Property Tax Rate (%)"),
                        dcc.Input(id="property-tax-input", type="number", min=0.1, max=5, step=0.01, value=0.65, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("HOA Fees ($/month)"),
                        dcc.Input(id="hoa-fees-input", type="number", min=0, max=2000, step=10, value=0, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Insurance Rate ($/year per $100k value)"),
                        dcc.Input(id="insurance-rate-input", type="number", min=200, max=2000, step=10, value=350, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Maintenance (% of home value per year)"),
                        dcc.Input(id="maintenance-rate-input", type="number", min=0.1, max=5, step=0.1, value=1, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Utilities ($/month)"),
                        dcc.Input(id="utilities-input", type="number", min=100, max=1000, step=10, value=250, className="form-control"),
                    ], className="form-group"),
                    html.Div([
                        html.Label("Expected Annual Appreciation (%)"),
                        dcc.Input(id="appreciation-input", type="number", min=0, max=10, step=0.1, value=3, className="form-control"),
                    ], className="form-group"),
                    html.Button("Calculate Costs", id="calculate-costs-button", className="btn btn-primary btn-block"),
                ], className="sidebar-content"),
            ], className="sidebar"),
            
            # Main panel
            html.Div([
                # Tabs
                dcc.Tabs([
                    # Monthly Costs Tab
                    dcc.Tab(label="Monthly Costs", children=[
                        html.Div([
                            # Monthly cost summary
                            html.Div([
                                html.Div([
                                    html.H3("Total Monthly Cost", className="card-title"),
                                    html.Div(id="total-monthly-cost", className="value-display"),
                                ], className="card cost-card"),
                                
                                html.Div([
                                    html.H3("Monthly Breakdown", className="card-title"),
                                    html.Div(id="monthly-breakdown-content", className="breakdown-content"),
                                ], className="card breakdown-card"),
                                
                                html.Div([
                                    html.H3("Monthly Cost Chart", className="card-title"),
                                    dcc.Graph(id="monthly-cost-chart"),
                                ], className="card chart-card"),
                            ], className="cost-summary"),
                            
                            # Affordability analysis
                            html.Div([
                                html.H3("Affordability Analysis"),
                                html.Div(id="affordability-content", className="affordability-content"),
                            ], className="card affordability-card"),
                        ], className="tab-content"),
                    ]),
                    
                    # Annual Costs Tab
                    dcc.Tab(label="Annual Costs", children=[
                        html.Div([
                            # Annual cost summary
                            html.Div([
                                html.Div([
                                    html.H3("Total Annual Cost", className="card-title"),
                                    html.Div(id="total-annual-cost", className="value-display"),
                                ], className="card cost-card"),
                                
                                html.Div([
                                    html.H3("Annual Breakdown", className="card-title"),
                                    html.Div(id="annual-breakdown-content", className="breakdown-content"),
                                ], className="card breakdown-card"),
                                
                                html.Div([
                                    html.H3("Annual Cost Chart", className="card-title"),
                                    dcc.Graph(id="annual-cost-chart"),
                                ], className="card chart-card"),
                            ], className="cost-summary"),
                            
                            # Tax benefits
                            html.Div([
                                html.H3("Tax Benefits"),
                                html.Div(id="tax-benefits-content", className="tax-benefits-content"),
                            ], className="card tax-benefits-card"),
                        ], className="tab-content"),
                    ]),
                    
                    # Long-Term Projection Tab
                    dcc.Tab(label="Long-Term Projection", children=[
                        html.Div([
                            html.H3("30-Year Cost Projection"),
                            
                            # Projection chart
                            html.Div([
                                dcc.Graph(id="long-term-projection-chart"),
                            ], className="card projection-card"),
                            
                            # Equity building
                            html.Div([
                                html.H3("Equity Building"),
                                dcc.Graph(id="equity-building-chart"),
                            ], className="card equity-card"),
                            
                            # Projection summary
                            html.Div([
                                html.H3("Projection Summary"),
                                html.Div(id="projection-summary-content", className="projection-summary-content"),
                            ], className="card projection-summary-card"),
                        ], className="tab-content"),
                    ]),
                    
                    # Scenarios Tab
                    dcc.Tab(label="Scenarios", children=[
                        html.Div([
                            html.H3("Appreciation/Depreciation Scenarios"),
                            
                            # Scenario controls
                            html.Div([
                                html.Div([
                                    html.Label("Scenario 1: Conservative (%)"),
                                    dcc.Input(id="scenario1-input", type="number", min=-5, max=10, step=0.1, value=1.5, className="form-control"),
                                ], className="form-group col"),
                                html.Div([
                                    html.Label("Scenario 2: Moderate (%)"),
                                    dcc.Input(id="scenario2-input", type="number", min=-5, max=10, step=0.1, value=3, className="form-control"),
                                ], className="form-group col"),
                                html.Div([
                                    html.Label("Scenario 3: Optimistic (%)"),
                                    dcc.Input(id="scenario3-input", type="number", min=-5, max=10, step=0.1, value=5, className="form-control"),
                                ], className="form-group col"),
                                html.Button("Update Scenarios", id="update-scenarios-button", className="btn btn-primary"),
                            ], className="scenario-controls row"),
                            
                            # Scenario chart
                            html.Div([
                                dcc.Graph(id="scenarios-chart"),
                            ], className="card scenarios-card"),
                            
                            # Scenario comparison
                            html.Div([
                                html.H3("Scenario Comparison"),
                                html.Div(id="scenario-comparison-content", className="scenario-comparison-content"),
                            ], className="card scenario-comparison-card"),
                        ], className="tab-content"),
                    ]),
                    
                    # Closing Costs Tab
                    dcc.Tab(label="Closing Costs", children=[
                        html.Div([
                            html.H3("Estimated Closing Costs"),
                            
                            # Closing costs breakdown
                            html.Div([
                                html.Div(id="closing-costs-content", className="closing-costs-content"),
                            ], className="card closing-costs-card"),
                            
                            # Closing costs chart
                            html.Div([
                                dcc.Graph(id="closing-costs-chart"),
                            ], className="card closing-costs-chart-card"),
                            
                            # Cash needed to close
                            html.Div([
                                html.H3("Cash Needed to Close"),
                                html.Div(id="cash-to-close-content", className="cash-to-close-content"),
                            ], className="card cash-to-close-card"),
                        ], className="tab-content"),
                    ]),
                ], className="tabs"),
            ], className="main-panel"),
        ], className="main-content"),
        
        # Footer
        html.Div([
            html.P("© 2025 XGBoost Home Valuation System | Clark County, Nevada"),
            html.P([
                html.A("Terms of Service", href="#"),
                " | ",
                html.A("Privacy Policy", href="#"),
                " | ",
                html.A("Contact Us", href="#"),
            ]),
        ], className="footer"),
        
        # Store components for intermediate data
        dcc.Store(id="property-data-store"),
        dcc.Store(id="monthly-costs-store"),
        dcc.Store(id="annual-costs-store"),
        dcc.Store(id="projection-data-store"),
        dcc.Store(id="scenarios-data-store"),
        dcc.Store(id="closing-costs-store"),
    ], className="app-container")

# Set the app layout
app.layout = create_buyer_layout()

# Callback to update down payment amount
@app.callback(
    Output("down-payment-amount", "children"),
    [Input("purchase-price-input", "value"), Input("down-payment-slider", "value")],
    prevent_initial_call=True
)
def update_down_payment_amount(purchase_price, down_payment_percent):
    """
    Update the down payment amount based on purchase price and percentage.
    
    Args:
        purchase_price: Purchase price of the property.
        down_payment_percent: Down payment percentage.
        
    Returns:
        str: Formatted down payment amount.
    """
    if not purchase_price or not down_payment_percent:
        return "Down Payment: $0"
    
    down_payment_amount = purchase_price * (down_payment_percent / 100)
    return f"Down Payment: ${down_payment_amount:,.0f}"

# Callback to calculate costs and update stores
@app.callback(
    [
        Output("property-data-store", "data"),
        Output("monthly-costs-store", "data"),
        Output("annual-costs-store", "data"),
        Output("projection-data-store", "data"),
        Output("closing-costs-store", "data"),
    ],
    [Input("calculate-costs-button", "n_clicks")],
    [
        State("address-input", "value"),
        State("property-type-dropdown", "value"),
        State("purchase-price-input", "value"),
        State("down-payment-slider", "value"),
        State("loan-term-dropdown", "value"),
        State("interest-rate-input", "value"),
        State("property-tax-input", "value"),
        State("hoa-fees-input", "value"),
        State("insurance-rate-input", "value"),
        State("maintenance-rate-input", "value"),
        State("utilities-input", "value"),
        State("appreciation-input", "value"),
    ],
    prevent_initial_call=True
)
def calculate_costs(n_clicks, address, property_type, purchase_price, down_payment_percent, 
                   loan_term, interest_rate, property_tax_rate, hoa_fees, insurance_rate, 
                   maintenance_rate, utilities, appreciation_rate):
    """
    Calculate costs based on user inputs.
    
    Args:
        n_clicks: Number of clicks on the button.
        address: Property address.
        property_type: Property type.
        purchase_price: Purchase price of the property.
        down_payment_percent: Down payment percentage.
        loan_term: Loan term in years.
        interest_rate: Interest rate percentage.
        property_tax_rate: Property tax rate percentage.
        hoa_fees: HOA fees per month.
        insurance_rate: Insurance rate per $100k value per year.
        maintenance_rate: Maintenance rate percentage of home value per year.
        utilities: Utilities cost per month.
        appreciation_rate: Expected annual appreciation percentage.
        
    Returns:
        tuple: Property data, monthly costs, annual costs, projection data, and closing costs.
    """
    # Create property data dictionary
    property_data = {
        "address": address,
        "property_type": property_type,
        "purchase_price": purchase_price,
        "down_payment_percent": down_payment_percent,
        "down_payment_amount": purchase_price * (down_payment_percent / 100),
        "loan_amount": purchase_price * (1 - down_payment_percent / 100),
        "loan_term": loan_term,
        "interest_rate": interest_rate,
        "property_tax_rate": property_tax_rate,
        "hoa_fees": hoa_fees,
        "insurance_rate": insurance_rate,
        "maintenance_rate": maintenance_rate,
        "utilities": utilities,
        "appreciation_rate": appreciation_rate
    }
    
    # Calculate monthly mortgage payment (principal and interest)
    monthly_interest_rate = interest_rate / 100 / 12
    num_payments = loan_term * 12
    loan_amount = property_data["loan_amount"]
    
    if monthly_interest_rate > 0:
        monthly_mortgage = loan_amount * (monthly_interest_rate * (1 + monthly_interest_rate) ** num_payments) / ((1 + monthly_interest_rate) ** num_payments - 1)
    else:
        monthly_mortgage = loan_amount / num_payments
    
    # Calculate other monthly costs
    monthly_property_tax = purchase_price * (property_tax_rate / 100) / 12
    monthly_insurance = purchase_price * (insurance_rate / 100000) / 12
    monthly_hoa = hoa_fees
    monthly_maintenance = purchase_price * (maintenance_rate / 100) / 12
    monthly_utilities = utilities
    
    # Calculate total monthly cost
    total_monthly_cost = monthly_mortgage + monthly_property_tax + monthly_insurance + monthly_hoa + monthly_maintenance + monthly_utilities
    
    # Create monthly costs dictionary
    monthly_costs = {
        "mortgage": monthly_mortgage,
        "property_tax": monthly_property_tax,
        "insurance": monthly_insurance,
        "hoa": monthly_hoa,
        "maintenance": monthly_maintenance,
        "utilities": monthly_utilities,
        "total": total_monthly_cost,
        "breakdown": [
            {"category": "Mortgage (P&I)", "amount": monthly_mortgage, "percentage": monthly_mortgage / total_monthly_cost * 100},
            {"category": "Property Tax", "amount": monthly_property_tax, "percentage": monthly_property_tax / total_monthly_cost * 100},
            {"category": "Insurance", "amount": monthly_insurance, "percentage": monthly_insurance / total_monthly_cost * 100},
            {"category": "HOA Fees", "amount": monthly_hoa, "percentage": monthly_hoa / total_monthly_cost * 100},
            {"category": "Maintenance", "amount": monthly_maintenance, "percentage": monthly_maintenance / total_monthly_cost * 100},
            {"category": "Utilities", "amount": monthly_utilities, "percentage": monthly_utilities / total_monthly_cost * 100}
        ]
    }
    
    # Calculate annual costs
    annual_mortgage = monthly_mortgage * 12
    annual_property_tax = monthly_property_tax * 12
    annual_insurance = monthly_insurance * 12
    annual_hoa = monthly_hoa * 12
    annual_maintenance = monthly_maintenance * 12
    annual_utilities = monthly_utilities * 12
    total_annual_cost = annual_mortgage + annual_property_tax + annual_insurance + annual_hoa + annual_maintenance + annual_utilities
    
    # Create annual costs dictionary
    annual_costs = {
        "mortgage": annual_mortgage,
        "property_tax": annual_property_tax,
        "insurance": annual_insurance,
        "hoa": annual_hoa,
        "maintenance": annual_maintenance,
        "utilities": annual_utilities,
        "total": total_annual_cost,
        "breakdown": [
            {"category": "Mortgage (P&I)", "amount": annual_mortgage, "percentage": annual_mortgage / total_annual_cost * 100},
            {"category": "Property Tax", "amount": annual_property_tax, "percentage": annual_property_tax / total_annual_cost * 100},
            {"category": "Insurance", "amount": annual_insurance, "percentage": annual_insurance / total_annual_cost * 100},
            {"category": "HOA Fees", "amount": annual_hoa, "percentage": annual_hoa / total_annual_cost * 100},
            {"category": "Maintenance", "amount": annual_maintenance, "percentage": annual_maintenance / total_annual_cost * 100},
            {"category": "Utilities", "amount": annual_utilities, "percentage": annual_utilities / total_annual_cost * 100}
        ],
        "tax_benefits": {
            "mortgage_interest": calculate_first_year_interest(loan_amount, interest_rate, loan_term),
            "property_tax": annual_property_tax
        }
    }
    
    # Calculate 30-year projection
    projection_data = calculate_projection(property_data, monthly_costs)
    
    # Calculate closing costs
    closing_costs = calculate_closing_costs(property_data)
    
    return property_data, monthly_costs, annual_costs, projection_data, closing_costs

# Helper function to calculate first year interest
def calculate_first_year_interest(loan_amount, interest_rate, loan_term):
    """
    Calculate the first year interest payments.
    
    Args:
        loan_amount: Loan amount.
        interest_rate: Interest rate percentage.
        loan_term: Loan term in years.
        
    Returns:
        float: First year interest payments.
    """
    monthly_interest_rate = interest_rate / 100 / 12
    num_payments = loan_term * 12
    
    if monthly_interest_rate > 0:
        monthly_payment = loan_amount * (monthly_interest_rate * (1 + monthly_interest_rate) ** num_payments) / ((1 + monthly_interest_rate) ** num_payments - 1)
    else:
        monthly_payment = loan_amount / num_payments
    
    # Calculate first year interest
    remaining_balance = loan_amount
    first_year_interest = 0
    
    for i in range(12):
        interest_payment = remaining_balance * monthly_interest_rate
        principal_payment = monthly_payment - interest_payment
        remaining_balance -= principal_payment
        first_year_interest += interest_payment
    
    return first_year_interest

# Helper function to calculate 30-year projection
def calculate_projection(property_data, monthly_costs):
    """
    Calculate 30-year projection of costs and equity.
    
    Args:
        property_data: Property data dictionary.
        monthly_costs: Monthly costs dictionary.
        
    Returns:
        dict: Projection data.
    """
    # Extract data
    purchase_price = property_data["purchase_price"]
    loan_amount = property_data["loan_amount"]
    loan_term = property_data["loan_term"]
    interest_rate = property_data["interest_rate"]
    property_tax_rate = property_data["property_tax_rate"]
    hoa_fees = property_data["hoa_fees"]
    insurance_rate = property_data["insurance_rate"]
    maintenance_rate = property_data["maintenance_rate"]
    utilities = property_data["utilities"]
    appreciation_rate = property_data["appreciation_rate"]
    
    # Calculate monthly payment
    monthly_interest_rate = interest_rate / 100 / 12
    num_payments = loan_term * 12
    
    if monthly_interest_rate > 0:
        monthly_payment = loan_amount * (monthly_interest_rate * (1 + monthly_interest_rate) ** num_payments) / ((1 + monthly_interest_rate) ** num_payments - 1)
    else:
        monthly_payment = loan_amount / num_payments
    
    # Initialize projection arrays
    years = list(range(1, 31))
    property_values = []
    loan_balances = []
    equity_values = []
    annual_costs = []
    cumulative_costs = []
    
    # Calculate amortization schedule
    remaining_balance = loan_amount
    
    # Assume 2% annual inflation for expenses
    inflation_rate = 0.02
    
    # Calculate projection for each year
    for year in range(1, 31):
        # Calculate property value with appreciation
        property_value = purchase_price * (1 + appreciation_rate / 100) ** year
        property_values.append(property_value)
        
        # Calculate loan balance
        if year <= loan_term:
            for month in range(12):
                interest_payment = remaining_balance * monthly_interest_rate
                principal_payment = monthly_payment - interest_payment
                remaining_balance -= principal_payment
            
            loan_balances.append(remaining_balance)
        else:
            loan_balances.append(0)
        
        # Calculate equity
        equity = property_value - loan_balances[-1]
        equity_values.append(equity)
        
        # Calculate annual costs with inflation
        inflation_factor = (1 + inflation_rate) ** (year - 1)
        
        annual_mortgage = monthly_payment * 12 if year <= loan_term else 0
        annual_property_tax = property_value * (property_tax_rate / 100)
        annual_insurance = property_value * (insurance_rate / 100000)
        annual_hoa = hoa_fees * 12 * inflation_factor
        annual_maintenance = property_value * (maintenance_rate / 100)
        annual_utilities = utilities * 12 * inflation_factor
        
        total_annual_cost = annual_mortgage + annual_property_tax + annual_insurance + annual_hoa + annual_maintenance + annual_utilities
        annual_costs.append(total_annual_cost)
        
        # Calculate cumulative costs
        if year == 1:
            cumulative_costs.append(total_annual_cost)
        else:
            cumulative_costs.append(cumulative_costs[-1] + total_annual_cost)
    
    # Create projection data dictionary
    projection_data = {
        "years": years,
        "property_values": property_values,
        "loan_balances": loan_balances,
        "equity_values": equity_values,
        "annual_costs": annual_costs,
        "cumulative_costs": cumulative_costs,
        "total_cost_30_year": sum(annual_costs),
        "final_property_value": property_values[-1],
        "final_equity": equity_values[-1],
        "roi": (equity_values[-1] - property_data["down_payment_amount"]) / property_data["down_payment_amount"] * 100
    }
    
    return projection_data

# Helper function to calculate closing costs
def calculate_closing_costs(property_data):
    """
    Calculate closing costs.
    
    Args:
        property_data: Property data dictionary.
        
    Returns:
        dict: Closing costs data.
    """
    # Extract data
    purchase_price = property_data["purchase_price"]
    loan_amount = property_data["loan_amount"]
    down_payment_amount = property_data["down_payment_amount"]
    
    # Calculate closing costs
    loan_origination_fee = loan_amount * 0.01
    appraisal_fee = 500
    credit_report_fee = 50
    title_insurance = purchase_price * 0.005
    escrow_fee = 500
    recording_fee = 100
    transfer_tax = purchase_price * 0.0025
    home_inspection = 400
    
    # Calculate total closing costs
    total_closing_costs = loan_origination_fee + appraisal_fee + credit_report_fee + title_insurance + escrow_fee + recording_fee + transfer_tax + home_inspection
    
    # Calculate cash needed to close
    cash_to_close = down_payment_amount + total_closing_costs
    
    # Create closing costs dictionary
    closing_costs = {
        "breakdown": [
            {"category": "Loan Origination Fee", "amount": loan_origination_fee, "percentage": loan_origination_fee / total_closing_costs * 100},
            {"category": "Appraisal Fee", "amount": appraisal_fee, "percentage": appraisal_fee / total_closing_costs * 100},
            {"category": "Credit Report Fee", "amount": credit_report_fee, "percentage": credit_report_fee / total_closing_costs * 100},
            {"category": "Title Insurance", "amount": title_insurance, "percentage": title_insurance / total_closing_costs * 100},
            {"category": "Escrow Fee", "amount": escrow_fee, "percentage": escrow_fee / total_closing_costs * 100},
            {"category": "Recording Fee", "amount": recording_fee, "percentage": recording_fee / total_closing_costs * 100},
            {"category": "Transfer Tax", "amount": transfer_tax, "percentage": transfer_tax / total_closing_costs * 100},
            {"category": "Home Inspection", "amount": home_inspection, "percentage": home_inspection / total_closing_costs * 100}
        ],
        "total": total_closing_costs,
        "cash_to_close": cash_to_close,
        "cash_breakdown": [
            {"category": "Down Payment", "amount": down_payment_amount, "percentage": down_payment_amount / cash_to_close * 100},
            {"category": "Closing Costs", "amount": total_closing_costs, "percentage": total_closing_costs / cash_to_close * 100}
        ]
    }
    
    return closing_costs

# Callback to update monthly costs display
@app.callback(
    [
        Output("total-monthly-cost", "children"),
        Output("monthly-breakdown-content", "children"),
        Output("monthly-cost-chart", "figure"),
        Output("affordability-content", "children"),
    ],
    [Input("monthly-costs-store", "data"), Input("property-data-store", "data")],
    prevent_initial_call=True
)
def update_monthly_costs_display(monthly_costs, property_data):
    """
    Update the monthly costs display.
    
    Args:
        monthly_costs: Monthly costs data.
        property_data: Property data.
        
    Returns:
        tuple: Updated display components.
    """
    if not monthly_costs or not property_data:
        return dash.no_update
    
    # Format the total monthly cost
    total_monthly_cost = f"${monthly_costs['total']:,.2f}"
    
    # Create monthly breakdown content
    breakdown_items = []
    for item in monthly_costs['breakdown']:
        breakdown_items.append(html.Div([
            html.Div([
                html.Div(item['category'], className="breakdown-category"),
                html.Div(f"${item['amount']:,.2f}", className="breakdown-amount"),
            ], className="breakdown-header"),
            html.Div([
                html.Div(className="breakdown-bar-container", children=[
                    html.Div(className="breakdown-bar", style={"width": f"{item['percentage']}%"}),
                ]),
                html.Div(f"{item['percentage']:.1f}%", className="breakdown-percentage"),
            ], className="breakdown-details"),
        ], className="breakdown-item"))
    
    monthly_breakdown_content = html.Div(breakdown_items, className="breakdown-items")
    
    # Create monthly cost chart
    categories = [item['category'] for item in monthly_costs['breakdown']]
    amounts = [item['amount'] for item in monthly_costs['breakdown']]
    
    fig = go.Figure(data=[go.Pie(
        labels=categories,
        values=amounts,
        hole=0.4,
        marker=dict(colors=['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'])
    )])
    
    fig.update_layout(
        title="Monthly Cost Breakdown",
        template="plotly_white"
    )
    
    # Create affordability analysis
    purchase_price = property_data['purchase_price']
    monthly_income_needed = monthly_costs['total'] / 0.28  # Assuming 28% of gross income for housing
    annual_income_needed = monthly_income_needed * 12
    
    affordability_content = html.Div([
        html.Div([
            html.H4("Income Requirements"),
            html.Div([
                html.Div([
                    html.H5("Monthly Income Needed"),
                    html.Div(f"${monthly_income_needed:,.2f}", className="income-value"),
                    html.Div("(Based on 28% of gross income for housing)", className="income-note"),
                ], className="income-item"),
                html.Div([
                    html.H5("Annual Income Needed"),
                    html.Div(f"${annual_income_needed:,.2f}", className="income-value"),
                ], className="income-item"),
            ], className="income-requirements"),
        ], className="affordability-section"),
        
        html.Div([
            html.H4("Price to Income Ratio"),
            html.Div([
                html.Div(f"{purchase_price / annual_income_needed:.1f}x", className="ratio-value"),
                html.Div([
                    html.Span("Recommended: 2.5x - 3.5x", className="ratio-recommendation"),
                    html.Div(className="ratio-indicator", children=[
                        html.Div(className="ratio-bar", style={"width": f"{min(100, (purchase_price / annual_income_needed) / 5 * 100)}%"}),
                    ]),
                ], className="ratio-details"),
            ], className="price-income-ratio"),
        ], className="affordability-section"),
        
        html.Div([
            html.H4("Front-End Ratio"),
            html.Div([
                html.Div(f"28%", className="ratio-value"),
                html.Div("(Housing costs as percentage of gross income)", className="ratio-note"),
            ], className="front-end-ratio"),
        ], className="affordability-section"),
        
        html.Div([
            html.H4("Back-End Ratio"),
            html.Div([
                html.Div(f"36%", className="ratio-value"),
                html.Div("(Total debt payments as percentage of gross income)", className="ratio-note"),
                html.Div("Note: This is an estimate. Your actual back-end ratio depends on your other debt obligations.", className="ratio-disclaimer"),
            ], className="back-end-ratio"),
        ], className="affordability-section"),
    ])
    
    return total_monthly_cost, monthly_breakdown_content, fig, affordability_content

# Callback to update annual costs display
@app.callback(
    [
        Output("total-annual-cost", "children"),
        Output("annual-breakdown-content", "children"),
        Output("annual-cost-chart", "figure"),
        Output("tax-benefits-content", "children"),
    ],
    [Input("annual-costs-store", "data")],
    prevent_initial_call=True
)
def update_annual_costs_display(annual_costs):
    """
    Update the annual costs display.
    
    Args:
        annual_costs: Annual costs data.
        
    Returns:
        tuple: Updated display components.
    """
    if not annual_costs:
        return dash.no_update
    
    # Format the total annual cost
    total_annual_cost = f"${annual_costs['total']:,.2f}"
    
    # Create annual breakdown content
    breakdown_items = []
    for item in annual_costs['breakdown']:
        breakdown_items.append(html.Div([
            html.Div([
                html.Div(item['category'], className="breakdown-category"),
                html.Div(f"${item['amount']:,.2f}", className="breakdown-amount"),
            ], className="breakdown-header"),
            html.Div([
                html.Div(className="breakdown-bar-container", children=[
                    html.Div(className="breakdown-bar", style={"width": f"{item['percentage']}%"}),
                ]),
                html.Div(f"{item['percentage']:.1f}%", className="breakdown-percentage"),
            ], className="breakdown-details"),
        ], className="breakdown-item"))
    
    annual_breakdown_content = html.Div(breakdown_items, className="breakdown-items")
    
    # Create annual cost chart
    categories = [item['category'] for item in annual_costs['breakdown']]
    amounts = [item['amount'] for item in annual_costs['breakdown']]
    
    fig = go.Figure(data=[go.Bar(
        x=categories,
        y=amounts,
        marker=dict(color=['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'])
    )])
    
    fig.update_layout(
        title="Annual Cost Breakdown",
        xaxis_title="Category",
        yaxis_title="Amount ($)",
        yaxis=dict(tickformat="$,.0f"),
        template="plotly_white"
    )
    
    # Create tax benefits content
    mortgage_interest = annual_costs['tax_benefits']['mortgage_interest']
    property_tax = annual_costs['tax_benefits']['property_tax']
    total_deductions = mortgage_interest + property_tax
    
    # Estimate tax savings (assuming 22% tax bracket)
    tax_savings = total_deductions * 0.22
    
    tax_benefits_content = html.Div([
        html.Div([
            html.H4("Potential Tax Deductions"),
            html.Div([
                html.Div([
                    html.H5("Mortgage Interest"),
                    html.Div(f"${mortgage_interest:,.2f}", className="deduction-value"),
                ], className="deduction-item"),
                html.Div([
                    html.H5("Property Tax"),
                    html.Div(f"${property_tax:,.2f}", className="deduction-value"),
                ], className="deduction-item"),
                html.Div([
                    html.H5("Total Deductions"),
                    html.Div(f"${total_deductions:,.2f}", className="deduction-value"),
                ], className="deduction-item total"),
            ], className="deductions-list"),
        ], className="tax-benefits-section"),
        
        html.Div([
            html.H4("Estimated Tax Savings"),
            html.Div([
                html.Div(f"${tax_savings:,.2f}", className="savings-value"),
                html.Div("(Assuming 22% tax bracket)", className="savings-note"),
            ], className="tax-savings"),
            html.Div([
                html.Div("Note: Tax benefits depend on your individual tax situation. Consult a tax professional for personalized advice.", className="tax-disclaimer"),
            ], className="tax-disclaimer-container"),
        ], className="tax-benefits-section"),
    ])
    
    return total_annual_cost, annual_breakdown_content, fig, tax_benefits_content

# Callback to update long-term projection display
@app.callback(
    [
        Output("long-term-projection-chart", "figure"),
        Output("equity-building-chart", "figure"),
        Output("projection-summary-content", "children"),
    ],
    [Input("projection-data-store", "data"), Input("property-data-store", "data")],
    prevent_initial_call=True
)
def update_long_term_projection(projection_data, property_data):
    """
    Update the long-term projection display.
    
    Args:
        projection_data: Projection data.
        property_data: Property data.
        
    Returns:
        tuple: Updated display components.
    """
    if not projection_data or not property_data:
        return dash.no_update
    
    # Create long-term projection chart
    fig1 = go.Figure()
    
    fig1.add_trace(go.Scatter(
        x=projection_data['years'],
        y=projection_data['annual_costs'],
        mode='lines+markers',
        name='Annual Cost',
        line=dict(color='#e74a3b', width=3),
        marker=dict(size=8)
    ))
    
    fig1.add_trace(go.Scatter(
        x=projection_data['years'],
        y=projection_data['cumulative_costs'],
        mode='lines',
        name='Cumulative Cost',
        line=dict(color='#4e73df', width=3, dash='dash'),
        yaxis='y2'
    ))
    
    fig1.update_layout(
        title="30-Year Cost Projection",
        xaxis_title="Year",
        yaxis_title="Annual Cost ($)",
        yaxis2=dict(
            title="Cumulative Cost ($)",
            overlaying='y',
            side='right',
            tickformat="$,.0f"
        ),
        yaxis=dict(tickformat="$,.0f"),
        template="plotly_white",
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    # Create equity building chart
    fig2 = go.Figure()
    
    fig2.add_trace(go.Scatter(
        x=projection_data['years'],
        y=projection_data['property_values'],
        mode='lines',
        name='Property Value',
        line=dict(color='#1cc88a', width=3),
        fill='tozeroy'
    ))
    
    fig2.add_trace(go.Scatter(
        x=projection_data['years'],
        y=projection_data['loan_balances'],
        mode='lines',
        name='Loan Balance',
        line=dict(color='#e74a3b', width=3),
        fill='tozeroy'
    ))
    
    fig2.add_trace(go.Scatter(
        x=projection_data['years'],
        y=projection_data['equity_values'],
        mode='lines',
        name='Equity',
        line=dict(color='#4e73df', width=3),
        fill='tonexty'
    ))
    
    fig2.update_layout(
        title="Equity Building Over Time",
        xaxis_title="Year",
        yaxis_title="Amount ($)",
        yaxis=dict(tickformat="$,.0f"),
        template="plotly_white",
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    # Create projection summary content
    purchase_price = property_data['purchase_price']
    down_payment = property_data['down_payment_amount']
    total_cost_30_year = projection_data['total_cost_30_year']
    final_property_value = projection_data['final_property_value']
    final_equity = projection_data['final_equity']
    roi = projection_data['roi']
    
    projection_summary_content = html.Div([
        html.Div([
            html.Div([
                html.H5("Initial Investment"),
                html.Div(f"${down_payment:,.2f}", className="summary-value"),
            ], className="summary-item"),
            html.Div([
                html.H5("Total 30-Year Cost"),
                html.Div(f"${total_cost_30_year:,.2f}", className="summary-value"),
            ], className="summary-item"),
            html.Div([
                html.H5("Final Property Value"),
                html.Div(f"${final_property_value:,.2f}", className="summary-value"),
            ], className="summary-item"),
            html.Div([
                html.H5("Final Equity"),
                html.Div(f"${final_equity:,.2f}", className="summary-value"),
            ], className="summary-item"),
            html.Div([
                html.H5("Return on Investment"),
                html.Div(f"{roi:.1f}%", className="summary-value"),
            ], className="summary-item"),
        ], className="projection-summary"),
        
        html.Div([
            html.H4("Key Insights"),
            html.Ul([
                html.Li(f"Your initial investment of ${down_payment:,.0f} could grow to ${final_equity:,.0f} in equity over 30 years."),
                html.Li(f"The property value is projected to increase from ${purchase_price:,.0f} to ${final_property_value:,.0f} based on {property_data['appreciation_rate']}% annual appreciation."),
                html.Li(f"Your total housing costs over 30 years are estimated to be ${total_cost_30_year:,.0f}."),
                html.Li(f"The return on your down payment investment is projected to be {roi:.1f}% over 30 years."),
                html.Li("These projections are estimates and actual results may vary based on market conditions and other factors."),
            ], className="insights-list"),
        ], className="key-insights"),
    ])
    
    return fig1, fig2, projection_summary_content

# Callback to update scenarios display
@app.callback(
    [
        Output("scenarios-data-store", "data"),
        Output("scenarios-chart", "figure"),
        Output("scenario-comparison-content", "children"),
    ],
    [Input("update-scenarios-button", "n_clicks")],
    [
        State("property-data-store", "data"),
        State("monthly-costs-store", "data"),
        State("scenario1-input", "value"),
        State("scenario2-input", "value"),
        State("scenario3-input", "value"),
    ],
    prevent_initial_call=True
)
def update_scenarios(n_clicks, property_data, monthly_costs, scenario1_rate, scenario2_rate, scenario3_rate):
    """
    Update the scenarios display.
    
    Args:
        n_clicks: Number of clicks on the button.
        property_data: Property data.
        monthly_costs: Monthly costs data.
        scenario1_rate: Appreciation rate for scenario 1.
        scenario2_rate: Appreciation rate for scenario 2.
        scenario3_rate: Appreciation rate for scenario 3.
        
    Returns:
        tuple: Updated scenarios data, chart, and comparison content.
    """
    if not property_data or not monthly_costs:
        return dash.no_update
    
    # Create a copy of property data for each scenario
    property_data1 = property_data.copy()
    property_data1['appreciation_rate'] = scenario1_rate
    property_data1['scenario_name'] = "Conservative"
    
    property_data2 = property_data.copy()
    property_data2['appreciation_rate'] = scenario2_rate
    property_data2['scenario_name'] = "Moderate"
    
    property_data3 = property_data.copy()
    property_data3['appreciation_rate'] = scenario3_rate
    property_data3['scenario_name'] = "Optimistic"
    
    # Calculate projections for each scenario
    projection1 = calculate_projection(property_data1, monthly_costs)
    projection2 = calculate_projection(property_data2, monthly_costs)
    projection3 = calculate_projection(property_data3, monthly_costs)
    
    # Create scenarios data
    scenarios_data = {
        "scenario1": {
            "name": "Conservative",
            "rate": scenario1_rate,
            "projection": projection1
        },
        "scenario2": {
            "name": "Moderate",
            "rate": scenario2_rate,
            "projection": projection2
        },
        "scenario3": {
            "name": "Optimistic",
            "rate": scenario3_rate,
            "projection": projection3
        }
    }
    
    # Create scenarios chart
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=projection1['years'],
        y=projection1['property_values'],
        mode='lines',
        name=f'Conservative ({scenario1_rate}%)',
        line=dict(color='#858796', width=3)
    ))
    
    fig.add_trace(go.Scatter(
        x=projection2['years'],
        y=projection2['property_values'],
        mode='lines',
        name=f'Moderate ({scenario2_rate}%)',
        line=dict(color='#4e73df', width=3)
    ))
    
    fig.add_trace(go.Scatter(
        x=projection3['years'],
        y=projection3['property_values'],
        mode='lines',
        name=f'Optimistic ({scenario3_rate}%)',
        line=dict(color='#1cc88a', width=3)
    ))
    
    fig.update_layout(
        title="Property Value Scenarios",
        xaxis_title="Year",
        yaxis_title="Property Value ($)",
        yaxis=dict(tickformat="$,.0f"),
        template="plotly_white",
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    # Create scenario comparison content
    scenario_comparison_content = html.Div([
        html.Div([
            html.H4("Scenario Comparison (After 30 Years)"),
            html.Div([
                html.Table([
                    html.Thead(
                        html.Tr([
                            html.Th("Scenario"),
                            html.Th("Annual Appreciation"),
                            html.Th("Final Property Value"),
                            html.Th("Final Equity"),
                            html.Th("Return on Investment"),
                        ])
                    ),
                    html.Tbody([
                        html.Tr([
                            html.Td("Conservative"),
                            html.Td(f"{scenario1_rate}%"),
                            html.Td(f"${projection1['final_property_value']:,.0f}"),
                            html.Td(f"${projection1['final_equity']:,.0f}"),
                            html.Td(f"{projection1['roi']:.1f}%"),
                        ]),
                        html.Tr([
                            html.Td("Moderate"),
                            html.Td(f"{scenario2_rate}%"),
                            html.Td(f"${projection2['final_property_value']:,.0f}"),
                            html.Td(f"${projection2['final_equity']:,.0f}"),
                            html.Td(f"{projection2['roi']:.1f}%"),
                        ]),
                        html.Tr([
                            html.Td("Optimistic"),
                            html.Td(f"{scenario3_rate}%"),
                            html.Td(f"${projection3['final_property_value']:,.0f}"),
                            html.Td(f"${projection3['final_equity']:,.0f}"),
                            html.Td(f"{projection3['roi']:.1f}%"),
                        ]),
                    ])
                ], className="scenario-comparison-table"),
            ], className="scenario-comparison-table-container"),
        ], className="scenario-comparison"),
        
        html.Div([
            html.H4("Risk Assessment"),
            html.P("The scenarios above represent different market conditions that could affect your investment:"),
            html.Ul([
                html.Li([
                    html.Strong("Conservative Scenario: "),
                    f"Assumes slower growth ({scenario1_rate}% annually) which might occur during economic downturns or in less desirable neighborhoods."
                ]),
                html.Li([
                    html.Strong("Moderate Scenario: "),
                    f"Represents average historical growth ({scenario2_rate}% annually) for the Clark County area."
                ]),
                html.Li([
                    html.Strong("Optimistic Scenario: "),
                    f"Reflects strong growth ({scenario3_rate}% annually) which might occur in highly desirable areas or during housing booms."
                ]),
            ]),
            html.P("Remember that real estate markets can be unpredictable, and past performance is not a guarantee of future results."),
        ], className="risk-assessment"),
    ])
    
    return scenarios_data, fig, scenario_comparison_content

# Callback to update closing costs display
@app.callback(
    [
        Output("closing-costs-content", "children"),
        Output("closing-costs-chart", "figure"),
        Output("cash-to-close-content", "children"),
    ],
    [Input("closing-costs-store", "data")],
    prevent_initial_call=True
)
def update_closing_costs_display(closing_costs):
    """
    Update the closing costs display.
    
    Args:
        closing_costs: Closing costs data.
        
    Returns:
        tuple: Updated display components.
    """
    if not closing_costs:
        return dash.no_update
    
    # Create closing costs content
    closing_costs_items = []
    for item in closing_costs['breakdown']:
        closing_costs_items.append(html.Div([
            html.Div([
                html.Div(item['category'], className="cost-category"),
                html.Div(f"${item['amount']:,.2f}", className="cost-amount"),
            ], className="cost-header"),
            html.Div([
                html.Div(className="cost-bar-container", children=[
                    html.Div(className="cost-bar", style={"width": f"{item['percentage']}%"}),
                ]),
                html.Div(f"{item['percentage']:.1f}%", className="cost-percentage"),
            ], className="cost-details"),
        ], className="closing-cost-item"))
    
    closing_costs_content = html.Div([
        html.Div([
            html.H4("Closing Costs Breakdown"),
            html.Div(closing_costs_items, className="closing-costs-items"),
            html.Div([
                html.H5("Total Closing Costs"),
                html.Div(f"${closing_costs['total']:,.2f}", className="total-closing-costs"),
            ], className="total-closing-costs-container"),
        ], className="closing-costs-breakdown"),
    ])
    
    # Create closing costs chart
    categories = [item['category'] for item in closing_costs['breakdown']]
    amounts = [item['amount'] for item in closing_costs['breakdown']]
    
    fig = go.Figure(data=[go.Bar(
        x=amounts,
        y=categories,
        orientation='h',
        marker=dict(color=['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796', '#5a5c69', '#2c9faf'])
    )])
    
    fig.update_layout(
        title="Closing Costs Breakdown",
        xaxis_title="Amount ($)",
        yaxis_title="Category",
        xaxis=dict(tickformat="$,.0f"),
        template="plotly_white",
        height=400
    )
    
    # Create cash to close content
    cash_to_close_content = html.Div([
        html.Div([
            html.H4("Cash Needed to Close"),
            html.Div(f"${closing_costs['cash_to_close']:,.2f}", className="cash-to-close-amount"),
        ], className="cash-to-close-header"),
        
        html.Div([
            html.Div([
                html.Div([
                    html.H5("Down Payment"),
                    html.Div(f"${closing_costs['cash_breakdown'][0]['amount']:,.2f}", className="cash-component-amount"),
                    html.Div(f"{closing_costs['cash_breakdown'][0]['percentage']:.1f}% of total", className="cash-component-percentage"),
                ], className="cash-component"),
                html.Div([
                    html.H5("Closing Costs"),
                    html.Div(f"${closing_costs['cash_breakdown'][1]['amount']:,.2f}", className="cash-component-amount"),
                    html.Div(f"{closing_costs['cash_breakdown'][1]['percentage']:.1f}% of total", className="cash-component-percentage"),
                ], className="cash-component"),
            ], className="cash-components"),
        ], className="cash-breakdown"),
        
        html.Div([
            html.H4("Preparation Tips"),
            html.Ul([
                html.Li("Have funds available in a liquid account at least 30 days before closing."),
                html.Li("Be prepared to provide bank statements showing the source of funds."),
                html.Li("Avoid large deposits or withdrawals close to closing date."),
                html.Li("Bring a cashier's check or prepare for a wire transfer on closing day."),
            ], className="preparation-tips-list"),
        ], className="preparation-tips"),
    ])
    
    return closing_costs_content, fig, cash_to_close_content

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True, host='0.0.0.0', port=8051)
